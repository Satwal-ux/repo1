/*
 * Class: CMSC201 
 * Instructor: Grigoriy Grinberg
 * Description: Create a program with several classes that create and declare variables/attributes which will 
  store student or employee data and prompt certain information questions and display it back to user
 * Due: 07/15/2024
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Sureena Atwal 
*/

import java.util.Scanner;

//create class Person
class Person {
	// declare variables and attributes to hold information
    private String name;
    private String address;
    private String phoneNumber;
    private String emailAddress;
    
    // Create constructor to initialize all attributes
    public Person(String name, String address, String phoneNumber, String emailAddress) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
    }

   // Create a toString method to return a string representation of the person's details 
    public String toString() {
        return "Name: " + name + "\nAddress: " + address + "\nPhone number: " + phoneNumber + "\nEmail address: " + emailAddress;
    }
}

// Create student class extending class Person
class Student extends Person {
	// Create and declare variables/attributes representing student's class grade
    public static final String FRESHMAN = "Freshman";
    public static final String SOPHOMORE = "Sophomore";
    public static final String JUNIOR = "Junior";
    public static final String SENIOR = "Senior";
    
    private final String status;

    // Create constructor that initializes all attributes 
    public Student(String name, String address, String phoneNumber, String emailAddress, String status) {
        super(name, address, phoneNumber, emailAddress);
        this.status = status;
    }

    // Create a toString method to return string of student's details 
    public String toString() {
        return super.toString() + "\nStatus: " + status;
    }
}

// insert given MyDate class to create an object for date hired
class MyDate {
    private String date;

    public MyDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }
}

// Create Employee class extending Person class
class Employee extends Person {
	// declare variables and use MyDate object to represent date hired
    private long officeNumber;
    private long salary;
    private MyDate dateHired;

    // Create constructor that initializes all attributes
    public Employee(String name, String address, String phoneNumber, String emailAddress, long officeNumber, long salary, MyDate dateHired) {
        super(name, address, phoneNumber, emailAddress);
        this.officeNumber = officeNumber;
        this.salary = salary;
        this.dateHired = dateHired;
    }

    // Create a toString method to return a string representation of employee details with office number, salary, and date hired
    public String toString() {
        return super.toString() + "\nOffice number: " + officeNumber + "\nSalary: " + salary + "\nDate hired: " + dateHired.getDate();
    }
}

// Create Faculty class extending employee class
class Faculty extends Employee {
	// Declare variables representing office hours and rank
    private String officeHours;
    private String rank;

    // Create constructor that initializes all attributes
    public Faculty(String name, String address, String phoneNumber, String emailAddress, long officeNumber, long salary, MyDate dateHired, String officeHours, String rank) {
        super(name, address, phoneNumber, emailAddress, officeNumber, salary, dateHired);
        this.officeHours = officeHours;
        this.rank = rank;
    }

    // Create a toString method to return faculty member details with office hours/rank
    public String toString() {
        return super.toString() + "\nOffice hours: " + officeHours + "\nRank: " + rank;
    }
}

// Create staff class extending employee class
class Staff extends Employee {
	// declare title variable
    private String title;

    // Create constructor to that initializes all attributes 
    public Staff(String name, String address, String phoneNumber, String emailAddress, long officeNumber, long salary, MyDate dateHired, String title) {
        super(name, address, phoneNumber, emailAddress, officeNumber, salary, dateHired);
        this.title = title;
    }

    // Create toString method to return representation of staff details with title
    public String toString() {
        return super.toString() + "\nTitle: " + title;
    }
}

// Create main driver class to test other classes; create objects based on user input and display the details 
public class PersonDriverApp {
    public static void main(String[] args) {
    	// input scanner for user input
        Scanner input = new Scanner(System.in);

        // Print the starting menu and prompt user to select the object they want to create
        System.out.println("Select the type of object to create:");
        System.out.println("1. To create a Student");
        System.out.println("2. To create an Employee: Faculty");
        System.out.println("3. To create an Employee: Staff");
        int choice = input.nextInt();
        input.nextLine();  
        
        // Prompt user to input basic information and store info
        System.out.println("Enter name:");
        String name = input.nextLine();
        System.out.println("Enter your address:");
        String address = input.nextLine();
        System.out.println("Enter phone number:");
        String phoneNumber = input.nextLine();
        System.out.println("Enter email address:");
        String emailAddress = input.nextLine();

        // create a switch method depending on input of user; prompt specific questions based off that and store info
        // Print info back at user, if invalid, state Invalid Choice
        switch (choice) {
            case 1:
                System.out.println("Enter status (Freshman, Sophomore, Junior, Senior):");
                String status = input.nextLine();
                Student student = new Student(name, address, phoneNumber, emailAddress, status);
                System.out.println(student);
                break;
            case 2:
                System.out.println("Enter an office number:");
                long officeNumber = input.nextLong();
                System.out.println("Enter a salary:");
                long salary = input.nextLong();
                System.out.println("Enter date hired (mm/dd/yyyy):");
                String dateHired = input.nextLine();
                System.out.println("Enter office hours:");
                String officeHours = input.nextLine();
                System.out.println("Enter a rank:");
                String rank = input.nextLine();
                Faculty faculty = new Faculty(name, address, phoneNumber, emailAddress, officeNumber, salary, new MyDate(dateHired), officeHours, rank);
                System.out.println(faculty);
                break;
            case 3:
                System.out.println("Enter an office number:");
                officeNumber = input.nextLong();
                System.out.println("Enter a salary:");
                salary = input.nextLong();
                System.out.println("Enter date hired (mm/dd/yyyy):");
                dateHired = input.nextLine();
                System.out.println("Enter a title:");
                String title = input.nextLine();
                Staff staff = new Staff(name, address, phoneNumber, emailAddress, officeNumber, salary, new MyDate(dateHired), title);
                System.out.println(staff);
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}